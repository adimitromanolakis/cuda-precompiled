
import torch
import soundfile as sf
import time
import random

from qwen_tts import Qwen3TTSModel

dtype = torch.float32
#dtype = torch.float16
dtype = torch.bfloat16

print("Init...")

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
flash_attn = get_kernel("kernels-community/flash-attn2")

model = Qwen3TTSModel.from_pretrained(
    #"/run/media/apo/Internal200/qwen3-tts/Qwen3-TTS-12Hz-1.7B-CustomVoice",
    "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice",
    device_map="cuda:0", #device_map="cpu:0",
    dtype=dtype,
    torch_dtype = dtype,
    #attn_implementation="flash_attention_2"
    attn_implementation="sdpa"
)


mods = [ m for m in model.model.modules()]

attn_layers = []
for m in model.model.modules():
    if hasattr(m, "self_attn"):
        attn_layers.append(m.self_attn)

for i, attn in enumerate(attn_layers[:15]):
    print(f"Layer {i}: {attn.__class__.__name__} { attn.config._attn_implementation}")



type = 'sdpa'
for i, attn in enumerate(attn_layers):
    attn.config._attn_implementation = type

for i, attn in enumerate(attn_layers[:15]):
    print(f"Layer {i}: {attn.__class__.__name__} { attn.config}")



model.get_supported_speakers()


print("Generate...")
start = time.perf_counter()

# single inference
wavs, sr = model.generate_custom_voice(
    text= str(random.randint(1,99999)) + """ Hey! Hello guys! What are you up to today? 
""",
    language="English", # Pass `Auto` (or omit) for auto language adaptive; if the target language is known, set it explicitly.
    speaker="vivian",
    seed=22,
    instruct="English formal speaker."
    #instruct="用特别愤怒的语气说", # Omit if not needed.
)


end = time.perf_counter()
print(f"  Inference time: {end - start:.3f} seconds")

model.model.speech_tokenizer.device


print("Write to WAV...")

sf.write("/tmp/output_custom_voice.wav", wavs[0], sr)

import subprocess

subprocess.run(["xdg-open", "/tmp/output_custom_voice.wav"]) 



